package ibf2022.batch2.csf.backend.repositories;

public class ImageRepository {

	//TODO: Task 3
	// You are free to change the parameter and the return type
	// Do not change the method's name
	public Object upload(/* any number of parameters here */) {
		return null;
	}
}
